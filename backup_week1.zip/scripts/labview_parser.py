#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from sensor_msgs.msg import JointState
from std_msgs.msg import Header
import numpy as np
from visualization_msgs.msg import Marker
from visualization_msgs.msg import MarkerArray
# http://wiki.ros.org/rviz/DisplayTypes/Marker#Message_Parameters


class UpdateRVIZMarker:

    def __init__(self,topic):
        self.publisher = rospy.Publisher(topic, MarkerArray, queue_size=10)
        
    def draw_rope(self, marker_id,rope_length,x_offset=0,y_offset=0,radius=0.015, frame_id="rope_mount_up_link_y"):
        marker = Marker()
        marker.id = marker_id
        marker.header.frame_id = frame_id
        marker.type = marker.CYLINDER
        marker.action = marker.ADD
        marker.scale.x = 2*radius
        marker.scale.y = 2*radius
        marker.scale.z = abs(rope_length)
        marker.color.a = 1.0
        marker.color.r = 0.1
        marker.color.g = 0.1
        marker.color.b = 0.1
        if rope_length < 0:
            marker.pose.orientation.w = 1.0
            marker.pose.orientation.z = 0.0
        else:
            marker.pose.orientation.w = 0.0
            marker.pose.orientation.z = 1.0

        marker.pose.position.y = y_offset
        marker.pose.position.x = x_offset 
        marker.pose.position.z = -abs(rope_length)/2 -0.3

        return marker

    def draw_load(self, mass_kg,density_kg_m3,frame_id="rotator"):
        r = (3/(4*3.14)*mass_kg/density_kg_m3)**(1./3)
        print(mass_kg,r)
        marker = Marker()
        marker.id = 201
        marker.header.frame_id = "rotator"
        marker.type = marker.SPHERE
        marker.action = marker.ADD
        marker.scale.x = r*2
        marker.scale.y = r*2
        marker.scale.z = r*2
        marker.color.a = 1.0
        marker.color.r = 129/255
        marker.color.g = 132/255
        marker.color.b = 121/255
        marker.pose.orientation.w = 1.0
        marker.pose.position.x = 0
        marker.pose.position.y = 0 
        marker.pose.position.z = -r-2.5

        return marker

    def delete_all_markers(self):
        reset_marker = Marker()
        reset_marker.header.frame_id = 'world'
        reset_marker.header.stamp = rospy.Time()
        reset_marker.action = 3 #code for deleteall
        return reset_marker

    def update_markers(self, rope_length,mass_kg,density_kg_m3):
        markerArray = MarkerArray()
        rope_right_mrkr =  self.draw_rope(101,rope_length,x_offset= 0,y_offset=-1.1,radius=0.03, frame_id="rope_mount_up_link_y")
        rope_mid_mrkr  = self.draw_rope(102,rope_length,x_offset=-1.4+1.4,y_offset=0,radius=0.015, frame_id="rope_mount_up_link_y")
        rope_left_mrkr = self.draw_rope(103,rope_length,x_offset=0,y_offset=+1.1,radius=0.03, frame_id="rope_mount_up_link_y")
        load_mrkr = self.draw_load(mass_kg, density_kg_m3)

        markerArray.markers.append(rope_right_mrkr)
        markerArray.markers.append(rope_mid_mrkr)
        markerArray.markers.append(rope_left_mrkr)
        markerArray.markers.append(load_mrkr)
        self.publisher.publish(markerArray)

##from rviz_updater import UpdateRVIZMarker

# (1) get ordered joint names from RVIZ, GUI, URDF:
JOINT_NAMES = ['bogie', 'boom_tower','rope_mount_up_joint_y',
    'rope','rope_mount_down_joint_y']

# (2) set initial pose values with GUI and copy Values:
INITIAL_POSE = [0.0,1.0,-1.0,-50.0,0.0] 

LOAD_kg = 1e4
LOAD_dnsty_kg_m3 = 2400 #kg/m^3

# Create Publisher on topic /joint_states
pub = rospy.Publisher('joint_states', JointState, queue_size=10)
rospy.init_node('viz_controller', anonymous=True)

vizUpdater = UpdateRVIZMarker('visualization_marker_array')

# Called for each dataframe from LABVIEW (PXI system)
def transform_callback(string_data=None):
    if string_data is None:
        new_joints = INITIAL_POSE
    else:
        # TO DO: calc joint values from callback data:
        new_joints = get_new_joints(string_data)

    # Publish the new Joint Positions:z
    global joint_pos_str 
    joint_pos_str = JointState()
    joint_pos_str.header = Header()
    joint_pos_str.header.stamp = rospy.Time.now()
    joint_pos_str.name = JOINT_NAMES
    joint_pos_str.position = new_joints
    joint_pos_str.velocity = []
    joint_pos_str.effort = []
    print(joint_pos_str)
    rospy.loginfo(joint_pos_str)
    pub.publish(joint_pos_str)

    rope_length = new_joints[-2]
    vizUpdater.update_markers(rope_length,LOAD_kg,LOAD_dnsty_kg_m3)


################################
# TO DO: get some physics done:
################################

def get_new_joints(data):
    """Function that calculates the new (relative??) joint positions 
    from the received subscriber data (=Labview data)"""
    
    # Dictionary as joint-value container:
    joint_values =	{}
    for j in JOINT_NAMES:
        joint_values[j]=0.0

    # Parse input data
    parsed_string = data.data.split(';')
    for idx, val in enumerate(parsed_string):
        key = list(joint_values)[idx]
        joint_values[key] = float(val.replace(",","."))

    
    parsed_joints = [float(i.replace(",",".")) for i in parsed_string]
    joint_values['rope_mount_up_joint_y'] = -joint_values['boom_tower']
    joint_values['rope'] *= (-1)
    joint_values['rope_mount_down_joint_y'] = 0.0 # set to 0 "swinging hook" otherwise

    print(list(joint_values.values()))
    return list(joint_values.values())



def viz_control_single_update():
    """    Handle Subscription and send start position    """
    rospy.Subscriber('/labview/state', String, transform_callback)
    # Initial movement.
    transform_callback()
    print("viz_control updated, waiting for next frame...")
    rospy.spin()


def viz_control_continous(rate=rospy.Rate(10)):
    """    Handle Subscription and jamm joint_coords    """
    rospy.Subscriber('/labview/state', String, transform_callback)
    transform_callback()
    while not rospy.is_shutdown():
        rospy.loginfo(joint_pos_str)
        pub.publish(joint_pos_str)
        rate.sleep()


#################################################
##               MAIN                          ##
#################################################

if __name__ == '__main__':
    try:
        #get_new_joints(String("0;2;3;4.55;-1.2"))
        viz_control_single_update()
    except rospy.ROSInterruptException:
        pass















