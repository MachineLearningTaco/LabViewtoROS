#!/usr/bin/env python

import rospy
from std_msgs.msg import String

def talker():
    #pub = rospy.Publisher('/labview/state', String, queue_size=10)
    pub = rospy.Publisher('/labview/state', String, queue_size=10)
    rospy.init_node('string_talker', anonymous=True)
    rate = rospy.Rate(100) # 10hz
    i=-3.14
    while not rospy.is_shutdown():
        hello_str = str(i)+";1;-1;"+str(25+i*5)+";0"
        i+=0.01
        if i >=3.14:
            i=-3.14

        rospy.loginfo(hello_str)
        pub.publish(hello_str)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass