#!/usr/bin/env python



from visualization_msgs.msg import Marker
from visualization_msgs.msg import MarkerArray
# http://wiki.ros.org/rviz/DisplayTypes/Marker#Message_Parameters

import rospy
import math
class UpdateRVIZMarker:

    def __init__(self,topic):
        self.publisher = rospy.Publisher(topic, MarkerArray, queue_size=10)
        
    def draw_rope(self, marker_id,rope_length,x_offset=0,y_offset=0,radius=0.015, frame_id="rope_mount_up_link_y"):
        marker = Marker()
        marker.id = marker_id
        marker.header.frame_id = frame_id
        marker.type = marker.CYLINDER
        marker.action = marker.ADD
        marker.scale.x = 2*radius
        marker.scale.y = 2*radius
        marker.scale.z = abs(rope_length)
        marker.color.a = 1.0
        marker.color.r = 0.1
        marker.color.g = 0.1
        marker.color.b = 0.1
        if rope_length < 0:
            marker.pose.orientation.w = 1.0
            marker.pose.orientation.z = 0.0
        else:
            marker.pose.orientation.w = 0.0
            marker.pose.orientation.z = 1.0

        marker.pose.position.y = y_offset
        marker.pose.position.x = x_offset 
        marker.pose.position.z = -abs(rope_length)/2 -0.3

        return marker

    def draw_load(self, mass_kg,density_kg_m3,frame_id="rotator"):
        r = (3/(4*3.14)*mass_kg/density_kg_m3)**(1./3)
        print(mass_kg,r)
        marker = Marker()
        marker.id = 201
        marker.header.frame_id = "rotator"
        marker.type = marker.SPHERE
        marker.action = marker.ADD
        marker.scale.x = r*2
        marker.scale.y = r*2
        marker.scale.z = r*2
        marker.color.a = 1.0
        marker.color.r = 129/255
        marker.color.g = 132/255
        marker.color.b = 121/255
        marker.pose.orientation.w = 1.0
        marker.pose.position.x = 0
        marker.pose.position.y = 0 
        marker.pose.position.z = -r-2.5

        return marker

    def delete_all_markers(self):
        reset_marker = Marker()
        reset_marker.header.frame_id = 'world'
        reset_marker.header.stamp = rospy.Time()
        reset_marker.action = 3 #code for deleteall
        return reset_marker

    def update_markers(self, rope_length,mass_kg,density_kg_m3):
        markerArray = MarkerArray()
        rope_right_mrkr =  self.draw_rope(101,rope_length,x_offset= 0,y_offset=-1.1,radius=0.03, frame_id="rope_mount_up_link_y")
        rope_mid_mrkr  = self.draw_rope(102,rope_length,x_offset=-1.4+1.4,y_offset=0,radius=0.015, frame_id="rope_mount_up_link_y")
        rope_left_mrkr = self.draw_rope(103,rope_length,x_offset=0,y_offset=+1.1,radius=0.03, frame_id="rope_mount_up_link_y")
        load_mrkr = self.draw_load(mass_kg, density_kg_m3)

        markerArray.markers.append(rope_right_mrkr)
        markerArray.markers.append(rope_mid_mrkr)
        markerArray.markers.append(rope_left_mrkr)
        markerArray.markers.append(load_mrkr)
        self.publisher.publish(markerArray)

if __name__ == '__main__':

    rvizUpdater = UpdateRVIZMarker('visualization_marker_array')

    while not rospy.is_shutdown(): 
        
        rvizUpdater.update_markers(50,1e4,2400)

        rospy.sleep(0.05)
