#!/usr/bin/env python

import rospy
from std_msgs.msg import String

from sensor_msgs.msg import JointState
from std_msgs.msg import Header

def update_joint():
    #create topic and init node
    pub = rospy.Publisher('joint_states', JointState, queue_size=10)
    rospy.init_node('joint_state_publisher', anonymous=True)
    rate = rospy.Rate(60) # 10hz publishing rate

    spinny = -3.14
    while not rospy.is_shutdown():
        
        spinny+=3.14/500
        if spinny >= 3.14:
            spinny=-3.14

        joint_pos_str = JointState()
        joint_pos_str.header = Header()
        joint_pos_str.header.stamp = rospy.Time.now()
        joint_pos_str.name = ['bogie', 'boom_tower','rope_mount_up_joint_y','rope','rope_mount_down_joint_y']
        joint_pos_str.position = [spinny, (abs(spinny))/3, (-1)*abs(spinny)/3, -50.0+abs(spinny)*10, 0.0]
        joint_pos_str.velocity = []
        joint_pos_str.effort = []
        print(joint_pos_str)

        rospy.loginfo(joint_pos_str)
        pub.publish(joint_pos_str)
        rate.sleep()

if __name__ == '__main__':
    try:
        update_joint()
    except rospy.ROSInterruptException:
        pass